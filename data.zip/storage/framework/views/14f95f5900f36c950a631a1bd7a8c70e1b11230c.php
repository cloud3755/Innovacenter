
   <body>
      <h1>Hola, Se pusieron en contacto con nosotros!</h1>
      <div>
      <b>Nombre:</b> <?php echo e($Contacto->Nombre); ?><br>
      <b>Correo:</b> <?php echo e($Contacto->Correo); ?><br>
      <b>Telefono:</b> <?php echo e($Contacto->Telefono); ?><br>
      <b>Mensaje:</b> <?php echo e($Contacto->Mensaje); ?><br>
      
      </div>
      <?php echo e(config('app.name')); ?>

   </body>

